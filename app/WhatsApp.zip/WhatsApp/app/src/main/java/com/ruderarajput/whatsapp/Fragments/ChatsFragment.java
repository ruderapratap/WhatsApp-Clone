package com.ruderarajput.whatsapp.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ruderarajput.whatsapp.Activity.AllUserActivity;
import com.ruderarajput.whatsapp.Adapter.UserAdapter;
import com.ruderarajput.whatsapp.Model.MessagesModel;
import com.ruderarajput.whatsapp.Model.User;
import com.ruderarajput.whatsapp.databinding.FragmentChatsBinding;

import java.util.ArrayList;

public class ChatsFragment extends Fragment {
    public ChatsFragment() {
    }

    FragmentChatsBinding binding;
    private UserAdapter userAdapter;
    private ArrayList<User> mUsers;
    FirebaseUser fuser;
    DatabaseReference reference;
    private ArrayList<String> usersList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChatsBinding.inflate(inflater, container, false);

        binding.alluserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), AllUserActivity.class);
                startActivity(intent);
            }
        });

        binding.recyclerView.setHasFixedSize(true);


       binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        fuser = FirebaseAuth.getInstance().getCurrentUser();
        usersList = new ArrayList<>();

        MessagesModel messageModel = new MessagesModel();
        reference = FirebaseDatabase.getInstance().getReference("chats").child(messageModel.getSenderId()+messageModel.getReceiverId()).child("messages");
        reference.addValueEventListener(new ValueEventListener() {
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usersList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    MessagesModel messageModel = dataSnapshot.getValue(MessagesModel.class);
                    if (messageModel != null && messageModel.getMessage() != null) {
                        if (messageModel.getSenderId().equals(fuser.getUid())) {
                            usersList.add(messageModel.getReceiverId());

                        }
                        if (messageModel.getReceiverId().equals(fuser.getUid())) {
                            usersList.add(messageModel.getSenderId());
                        }
                    }
                }
                readChats();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return binding.getRoot();
    }

    private void readChats() {
        mUsers=new ArrayList<>();
        reference = FirebaseDatabase.getInstance().getReference("users");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUsers.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    User user = dataSnapshot.getValue(User.class);
                    for (String id : usersList) {
                        if (user.getUid().equals(id)) {
                            if (mUsers.size() != 0) {
                                for (User user1 : mUsers) {
                                    if (!user.getUid().equals(user1.getUid())){
                                        mUsers.add(user);
                                    }
                                }
                            }else {
                                mUsers.add(user);
                            }
                        }
                    }
                }
                userAdapter=new UserAdapter(getContext(),mUsers);
                binding.recyclerView.setAdapter(userAdapter);
                //userAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}