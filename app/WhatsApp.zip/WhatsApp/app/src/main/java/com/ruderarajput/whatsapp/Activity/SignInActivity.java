package com.ruderarajput.whatsapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.FirebaseDatabase;
import com.ruderarajput.whatsapp.Model.User;
import com.ruderarajput.whatsapp.R;
import com.ruderarajput.whatsapp.databinding.ActivitySignInBinding;

public class SignInActivity extends AppCompatActivity {

    ActivitySignInBinding binding;
    ProgressDialog progressDialog;
    FirebaseAuth auth;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignInBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();


        binding.continueBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(binding.etMobile.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(SignInActivity.this, "Please Enter Your Mobile Number.", Toast.LENGTH_SHORT).show();
                    binding.etMobile.requestFocus();
                }
                if (binding.etEmail.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(SignInActivity.this, "Please Enter Your Email Address.", Toast.LENGTH_SHORT).show();
                    binding.etEmail.requestFocus();
                } else if (!binding.etEmail.getText().toString().trim().matches(emailPattern)) {
                    Toast.makeText(SignInActivity.this, "Please Enter Correct Email Address.", Toast.LENGTH_SHORT).show();
                    binding.etEmail.requestFocus();
                } else if (binding.etPassword.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(SignInActivity.this, "Please Enter Your Email Address.", Toast.LENGTH_SHORT).show();
                    binding.etPassword.requestFocus();
                } else if (binding.etPassword.getText().toString().trim().length() < 6) {
                    Toast.makeText(SignInActivity.this, "Please Enter Minimum 6 Digit Password.", Toast.LENGTH_SHORT).show();
                    binding.etPassword.requestFocus();
                } else if (!binding.etConfirmPassword.getText().toString().trim().equals(binding.etPassword.getText().toString().trim())) {
                    Toast.makeText(SignInActivity.this, "Confirm Password Doesn't Match.", Toast.LENGTH_SHORT).show();
                    binding.etPassword.requestFocus();
                }else {
                    Intent intent=new Intent(SignInActivity.this, OtpActivity.class);
                    intent.putExtra("phoneNumber",binding.etMobile.getText().toString());
                    startActivity(intent);
                }
            }
        });
        if(auth.getCurrentUser()!=null){
            Intent intent=new Intent(SignInActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
    }


